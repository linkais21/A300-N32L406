#include "gps_report_filter.h"
#include "i2c_accel.h"
#include "flash_config.h"
#include <math.h>
#include <string.h>

#define REPORT_WINDOW_COUNT      5u
#define REPORT_ACCEL_PERIOD_MS   200u
#define REPORT_ACCEL_GAP_MS      1000u
#define REPORT_FIX_MAX_AGE_MS    3000u
#define REPORT_MOVE_FIXES        3u
#define REPORT_ACCEL_LSB_PER_G   1024u
#define REPORT_FIX_HOLD_MS       10000u
#define REPORT_WEAK_SPEED_KMH    3.0f

typedef enum {
    REPORT_UNKNOWN = 0,
    REPORT_MOVING,
    REPORT_CANDIDATE,
    REPORT_LOCKED,
    REPORT_SUSPECT
} report_state_t;

/* L406 field trial: observed stationary windows reached 100 LSB (~98 mg).
 * Keep hysteresis and speed release; these thresholds require moving HIL. */
static const gps_report_filter_config_t s_config = {
    1.0f, 2.0f, 120u, 180u, 30000u
};
static struct {
    uint8_t state; /* report_state_t; compact to avoid alignment padding */
    uint8_t blockers;
    int16_t acceleration[REPORT_WINDOW_COUNT][3];
    /* Candidate samples and locked anchor have disjoint lifetimes.
     * 1e-7 degree samples preserve centimetre precision without 80 B doubles. */
    union {
        struct { int32_t lat[REPORT_WINDOW_COUNT], lon[REPORT_WINDOW_COUNT]; } fixes;
        struct {
            double lat, lon;
            int32_t ref_lat, ref_lon;
            float distance, heading;
            uint32_t started;
        } anchor;
    } position;
    uint32_t last_poll_ms, last_rmc_ms, candidate_ms;
    uint8_t fix_count, fix_next, move_count;
    float travel_m;
    uint32_t motion_ms;
    bool motion_pending;
    /* Five-entry ring and evidence flags fit in one byte; no persisted ABI. */
    uint8_t accel_count : 3;
    uint8_t accel_next : 3;
    uint8_t have_poll : 1;
    uint8_t have_rmc : 1;
} s_report;

static bool holding(void) { return s_report.state >= REPORT_LOCKED; }

static bool quality_good(const gps_data_t *g)
{
    return gps_quality_fix_fresh() && g->satellites >= 6u &&
           g->hdop > 0.0f && g->hdop <= 2.5f;
}

/* Local classification only; never project output coordinates.
 * cos(lat) = sin(pi/2-|lat|), degree-7 Taylor on [0,pi/2].
 * Absolute truncation error <= (pi/2)^9/9! < 0.000161. */
static float offset_m(const gps_data_t *g, int32_t lat, int32_t lon,
                      float *north, float *east)
{
    float x = (90.0f - fabsf((float)lat / 10000000.0f)) * 0.01745329252f;
    float z = x*x;
    float scale = x + x*z*(-1.0f/6.0f + z*(1.0f/120.0f - z/5040.0f));
    double delta = g->lon - (double)lon / 10000000.0;
    if (delta > 180.0) delta -= 360.0;
    if (delta < -180.0) delta += 360.0;
    *north = (float)(g->lat - (double)lat / 10000000.0) * 111319.5f;
    *east = (float)delta * (111319.5f * scale);
    return *north * *north + *east * *east;
}

/* Evidence is provisional, bounded, and discarded rather than replayed. */
static bool suspect_motion(const gps_data_t *g, uint32_t now, uint32_t dt)
{
    float north, east, distance, turn;
    static const int8_t direction[8][2] = {{1,0},{1,1},{0,1},{-1,1},
                                         {-1,0},{-1,-1},{0,-1},{1,-1}};
    if (g->speed_kmh < 0.5f || !(g->heading >= 0.0f && g->heading < 360.0f)) {
        s_report.state = REPORT_LOCKED;
        return false;
    }
    if (s_report.state == REPORT_LOCKED) {
        s_report.position.anchor.ref_lat = (int32_t)(g->lat * 10000000.0);
        s_report.position.anchor.ref_lon = (int32_t)(g->lon * 10000000.0);
        s_report.position.anchor.distance = 0.0f;
        s_report.position.anchor.heading = g->heading;
        s_report.position.anchor.started = now;
        s_report.travel_m = 0.0f;
        s_report.state = REPORT_SUSPECT;
        return false;
    }
    distance = offset_m(g, s_report.position.anchor.ref_lat,
                        s_report.position.anchor.ref_lon, &north, &east);
    turn = fabsf(g->heading - s_report.position.anchor.heading);
    if (turn > 180.0f) turn = 360.0f-turn;
    s_report.travel_m += g->speed_kmh * ((float)dt / 3600.0f);
    if (now-s_report.position.anchor.started > 60000u || turn > 30.0f ||
        distance + 1.0f < s_report.position.anchor.distance ||
        distance > 4.0f*s_report.travel_m*s_report.travel_m + 1.0f) {
        s_report.state = REPORT_LOCKED;
        return false;
    }
    s_report.position.anchor.distance = distance;
    unsigned sector = ((unsigned)((g->heading+22.5f)/45.0f)) % 8u;
    float dot = north*direction[sector][0] + east*direction[sector][1];
    unsigned norm = 1u + (sector & 1u);
    return now-s_report.position.anchor.started >= 10000u && distance >= 16.0f &&
           distance >= 0.25f*s_report.travel_m*s_report.travel_m && dot > 0.0f &&
           2.0f*dot*dot >= distance*norm;
}

bool gps_report_filter_motion_pending(uint32_t now_ms)
{
    if (now_ms-s_report.motion_ms > 15000u) s_report.motion_pending = false;
    return s_report.motion_pending;
}

void gps_report_filter_motion_ack(void) { s_report.motion_pending = false; }

static void confirm_motion(uint32_t now)
{
    if (holding()) {
        s_report.motion_ms = now;
        s_report.motion_pending = true;
    }
}

static bool report_enabled(void)
{
    const device_config_t *config = cfg_get();
    return config != NULL && config->stopdrift_en != 0u && gps_is_enabled();
}

static bool report_fix_fresh(const gps_data_t *gps, uint32_t now_ms)
{
    return (gps != NULL && gps->valid && gps_is_valid()) &&
           fabs(gps->lat) <= 90.0 && fabs(gps->lon) <= 180.0 &&
           isfinite(gps->speed_kmh) && gps->speed_kmh >= 0.0f &&
           now_ms - gps->last_update_ms <= REPORT_FIX_MAX_AGE_MS &&
           now_ms - gps->heading_update_ms <= REPORT_FIX_MAX_AGE_MS;
}

static void clear_candidate(report_state_t state)
{
    s_report.state = state;
    s_report.fix_count = 0u;
    s_report.fix_next = 0u;
    s_report.candidate_ms = 0u;
}

/* Retain poll deadline after failed reads: recovery must not busy-poll I2C. */
static void invalidate_evidence(void)
{
    s_report.motion_pending = false;
    clear_candidate(REPORT_UNKNOWN);
    s_report.accel_count = 0u;
    s_report.accel_next = 0u;
    s_report.move_count = 0u;
    s_report.have_rmc = false;
}

void gps_report_filter_reset(void)
{
    memset(&s_report, 0, sizeof(s_report));
}

void gps_report_filter_init(void)
{
    gps_report_filter_reset();
}

static bool acceleration_legal(const accel_data_t *a)
{
    /* Existing driver's signed >>4 representation has range -2048..2047.
     * Reject railed/zero samples; no-motion must not mean an unplugged sensor. */
    return a->x > -2048 && a->x < 2047 &&
           a->y > -2048 && a->y < 2047 &&
           a->z > -2048 && a->z < 2047 &&
           (a->x != 0 || a->y != 0 || a->z != 0);
}

static uint32_t acceleration_span(void)
{
    uint32_t span = 0u;
    for (uint8_t axis = 0u; axis < 3u; ++axis) {
        int16_t low = s_report.acceleration[0][axis], high = low;
        for (uint8_t i = 1u; i < s_report.accel_count; ++i) {
            int16_t value = s_report.acceleration[i][axis];
            if (value < low) low = value;
            if (value > high) high = value;
        }
        uint32_t delta = (uint32_t)((int32_t)high - (int32_t)low);
        if (delta > span) span = delta;
    }
    return span;
}

void gps_report_filter_get_diag(gps_report_filter_diag_t *out, uint32_t now_ms)
{
    if (out == NULL) return;
    out->state = s_report.state;
    out->blockers = s_report.blockers;
    out->span_lsb = s_report.accel_count ? (uint16_t)acceleration_span() : 0u;
    out->candidate_ms = s_report.state == REPORT_CANDIDATE ?
                        now_ms - s_report.candidate_ms : 0u;
}

/* Shared by latitude/longitude; inlining duplicates the 64-bit arithmetic. */
static __attribute__((noinline)) double trimmed_mean(const int32_t *values)
{
    const int64_t half_turn = 1800000000LL;
    int64_t origin = values[0];
    int64_t sum = origin, low = origin, high = origin;
    for (uint8_t i = 1u; i < REPORT_WINDOW_COUNT; i++) {
        int64_t value = values[i];
        /* Longitude is circular: unwrap around the first fix so stationary
         * samples at +180/-180 cannot average into a different continent.
         * Valid latitude differences never exceed 180 degrees, so the same
         * operation is an identity for latitude and needs no separate flag. */
        if (value - origin > half_turn) value -= 2 * half_turn;
        else if (value - origin < -half_turn) value += 2 * half_turn;
        sum += value;
        if (value < low) low = value;
        if (value > high) high = value;
    }
    /* At most five unwrapped e7 samples: int32 could overflow.
     * Normalize the retained sum before a single double conversion. */
    sum -= low + high;
    if (sum > 3 * half_turn) sum -= 6 * half_turn;
    else if (sum < -3 * half_turn) sum += 6 * half_turn;
    return (double)sum / 30000000.0;
}

void gps_report_filter_process(uint32_t now_ms)
{
    const gps_data_t *gps = gps_get_data();
    if (!report_enabled()) {
        s_report.blockers |= GPS_REPORT_BLOCK_DISABLED;
        invalidate_evidence();
        return;
    }
    if (s_report.have_poll &&
        now_ms - s_report.last_poll_ms > REPORT_ACCEL_GAP_MS) {
        s_report.blockers |= GPS_REPORT_BLOCK_GAP;
        invalidate_evidence();
    }
    if (!s_report.have_poll ||
        now_ms - s_report.last_poll_ms >= REPORT_ACCEL_PERIOD_MS) {
        accel_data_t a;
        s_report.last_poll_ms = now_ms;
        s_report.have_poll = true;
        if (!i2c_accel_read(&a) || !acceleration_legal(&a)) {
            s_report.blockers |= GPS_REPORT_BLOCK_SENSOR;
            invalidate_evidence();
            return;
        }
        s_report.acceleration[s_report.accel_next][0] = a.x;
        s_report.acceleration[s_report.accel_next][1] = a.y;
        s_report.acceleration[s_report.accel_next][2] = a.z;
        s_report.accel_next = (uint8_t)((s_report.accel_next + 1u) % REPORT_WINDOW_COUNT);
        if (s_report.accel_count < REPORT_WINDOW_COUNT) s_report.accel_count++;
    }
    if (s_report.accel_count == 0u) return;

    /* Keep observing motion through a short GNSS outage. A retained anchor
     * is never exported as a live fix until fresh valid GNSS returns. */
    uint32_t span_milli_lsb = acceleration_span() * 1000u;
    if (span_milli_lsb >= (uint32_t)s_config.move_accel_mg * REPORT_ACCEL_LSB_PER_G) {
        s_report.blockers |= GPS_REPORT_BLOCK_ACCEL;
        if (report_fix_fresh(gps, now_ms) && gps->speed_kmh >= 0.5f)
            confirm_motion(now_ms);
        clear_candidate(REPORT_MOVING);
        s_report.move_count = 0u;
        return;
    }
    if (holding() &&
        now_ms - s_report.candidate_ms > REPORT_FIX_HOLD_MS)
        clear_candidate(REPORT_UNKNOWN);
    if (!report_fix_fresh(gps, now_ms)) {
        s_report.motion_pending = false;
        s_report.blockers |= GPS_REPORT_BLOCK_FIX;
        s_report.move_count = 0u;
        s_report.have_rmc = false;
        if (!holding() ||
            span_milli_lsb > (uint32_t)s_config.stable_accel_mg * REPORT_ACCEL_LSB_PER_G)
            clear_candidate(REPORT_UNKNOWN);
        else s_report.state = REPORT_LOCKED;
        return;
    }

    /* Only an established stationary anchor may reject weak low-speed
     * evidence. Never use this exception to lock a vehicle already creeping.
     * Missing/invalid DOP is not evidence of a high-quality speed solution. */
    bool weak_speed = holding() &&
        span_milli_lsb <= (uint32_t)s_config.stable_accel_mg * REPORT_ACCEL_LSB_PER_G &&
        gps->speed_kmh <= REPORT_WEAK_SPEED_KMH &&
        !quality_good(gps);

    bool new_rmc = !s_report.have_rmc || gps->heading_update_ms != s_report.last_rmc_ms;
    uint32_t dt = gps->heading_update_ms - s_report.last_rmc_ms;
    if (new_rmc) {
        if (s_report.have_rmc &&
            gps->heading_update_ms - s_report.last_rmc_ms > REPORT_FIX_MAX_AGE_MS) {
            s_report.blockers |= GPS_REPORT_BLOCK_RMC_GAP;
            s_report.move_count = 0u;
            if (!holding())
                clear_candidate(REPORT_UNKNOWN);
            else s_report.state = REPORT_LOCKED;
        }
        s_report.have_rmc = true;
        s_report.last_rmc_ms = gps->heading_update_ms;
        if (!weak_speed && gps->speed_kmh >= s_config.move_speed_kmh) {
            if (s_report.move_count < REPORT_MOVE_FIXES) s_report.move_count++;
        } else {
            s_report.move_count = 0u;
        }
    }

    /* Distinct RMC confirmation, independent of main-loop call frequency. */
    if (s_report.move_count >= REPORT_MOVE_FIXES) {
        s_report.blockers |= GPS_REPORT_BLOCK_SPEED;
        confirm_motion(now_ms);
        clear_candidate(REPORT_MOVING);
        return;
    }
    if (holding()) {
        if (span_milli_lsb > (uint32_t)s_config.stable_accel_mg * REPORT_ACCEL_LSB_PER_G)
            s_report.state = REPORT_LOCKED;
        else if (new_rmc && suspect_motion(gps, now_ms, dt)) {
            confirm_motion(now_ms);
            clear_candidate(REPORT_MOVING);
            return;
        }
        s_report.candidate_ms = now_ms; /* locked: last fresh fix observation */
        return;
    }
    if (s_report.accel_count < REPORT_WINDOW_COUNT ||
        !quality_good(gps) ||
        span_milli_lsb > (uint32_t)s_config.stable_accel_mg * REPORT_ACCEL_LSB_PER_G ||
        gps->speed_kmh > s_config.stop_speed_kmh) {
        if (span_milli_lsb > (uint32_t)s_config.stable_accel_mg * REPORT_ACCEL_LSB_PER_G)
            s_report.blockers |= GPS_REPORT_BLOCK_UNSTABLE;
        if (gps->speed_kmh > s_config.stop_speed_kmh)
            s_report.blockers |= GPS_REPORT_BLOCK_SPEED;
        clear_candidate(REPORT_MOVING);
        return;
    }
    if (s_report.state != REPORT_CANDIDATE) {
        clear_candidate(REPORT_CANDIDATE);
        s_report.candidate_ms = now_ms;
    }
    if (new_rmc) {
        float north, east;
        if (s_report.fix_count &&
            offset_m(gps, s_report.position.fixes.lat[0],
                     s_report.position.fixes.lon[0], &north, &east) > 64.0f) {
            clear_candidate(REPORT_CANDIDATE);
            s_report.candidate_ms = now_ms;
        }
        s_report.position.fixes.lat[s_report.fix_next] = (int32_t)(gps->lat * 10000000.0);
        s_report.position.fixes.lon[s_report.fix_next] = (int32_t)(gps->lon * 10000000.0);
        s_report.fix_next++;
        if (s_report.fix_next == REPORT_WINDOW_COUNT) s_report.fix_next = 1u;
        if (s_report.fix_count < REPORT_WINDOW_COUNT) s_report.fix_count++;
    }
    if (s_report.fix_count == REPORT_WINDOW_COUNT &&
        now_ms - s_report.candidate_ms >= s_config.stationary_ms) {
        double lat = trimmed_mean(s_report.position.fixes.lat);
        double lon = trimmed_mean(s_report.position.fixes.lon);
        s_report.position.anchor.lat = lat;
        s_report.position.anchor.lon = lon;
        s_report.state = REPORT_LOCKED;
        s_report.candidate_ms = now_ms;
    }
}

bool gps_report_filter_copy(const gps_data_t *raw, gps_data_t *out, uint32_t now_ms)
{
    if (raw == NULL || out == NULL || raw == out) return false;
    *out = *raw;
    if (!report_enabled() || !holding() ||
        !report_fix_fresh(raw, now_ms) || !s_report.have_poll ||
        now_ms - s_report.last_poll_ms > REPORT_ACCEL_GAP_MS) return false;
    out->lat = s_report.position.anchor.lat;
    out->lon = s_report.position.anchor.lon;
    out->speed_kmh = 0.0f;
    out->heading = 0.0f;
    return true;
}
