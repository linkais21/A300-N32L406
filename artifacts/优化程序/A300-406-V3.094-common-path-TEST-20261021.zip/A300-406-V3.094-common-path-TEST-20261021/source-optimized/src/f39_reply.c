#include "f39_reply.h"
#include "terminal_identity.h"
#include "plate_encoding.h"
#include "fota.h"
#include "log_platform.h"

#include <stdarg.h>
#include <math.h>
#include <stdio.h>
#include "a300_format.h"
#include <string.h>

#ifdef A300_FIRMWARE_IMAGE
#include "f39_production_bindings.h"
#define F39_READY(p, field) ((p)->field == f39_production_##field)
#define F39_INVOKE(p, field, ...) f39_production_##field(__VA_ARGS__)
#else
#define F39_READY(p, field) ((p)->field != NULL)
#define F39_INVOKE(p, field, ...) ((p)->field(__VA_ARGS__))
#endif

static void reply_clear(f39_reply_t *reply)
{
    if (reply != NULL) {
        reply->len = 0U;
        reply->data[0] = '\0';
        reply->reset_pending = false;
        reply->reset_delay_ms = 0U;
    }
}

static bool reply_append(f39_reply_t *reply, const char *format, ...)
{
    va_list ap;
    int n;

    if (reply == NULL || format == NULL || reply->len >= F39_REPLY_MAX_LENGTH) {
        return false;
    }
    va_start(ap, format);
    n = vsnprintf((char *)&reply->data[reply->len],
                  F39_REPLY_MAX_LENGTH - reply->len, format, ap);
    va_end(ap);
    if (n < 0 || (uint32_t)n >= (uint32_t)(F39_REPLY_MAX_LENGTH - reply->len)) {
        reply->len = 0U;
        reply->data[0] = '\0';
        return false;
    }
    reply->len = (uint16_t)(reply->len + (uint16_t)n);
    return true;
}

static bool arg_text(const f39_request_t *request, uint8_t index,
                     char *buffer, uint16_t capacity)
{
    uint32_t end;
    uint16_t len;

    if (request == NULL || buffer == NULL || capacity == 0U ||
        index >= request->argc) {
        return false;
    }
    len = request->args[index].len;
    end = (uint32_t)request->args[index].offset + len;
    if (end > request->raw_len || len >= capacity) {
        return false;
    }
    (void)memcpy(buffer, &request->raw[request->args[index].offset], len);
    buffer[len] = '\0';
    return true;
}

static f39_result_t failure(f39_reply_t *reply, const char *name,
                            const char *reason)
{
    reply_clear(reply);
    (void)reply_append(reply, "%s=Fail! %s\r\n", name, reason);
    return F39_RESULT_INVALID;
}

/* One result path keeps exact truncation failure text for all queries. */
static f39_result_t reply_result(f39_reply_t *reply, const char *name, bool written)
{
    return written ? F39_RESULT_OK : failure(reply, name, "reply-too-long");
}

static f39_result_t success(f39_reply_t *reply, const char *name)
{
    reply_clear(reply);
    if (!reply_append(reply, "%s=Success!\r\n", name)) {
        return F39_RESULT_INVALID;
    }
    return F39_RESULT_OK;
}

/* Share scalar query formatting, including truncation/error handling. */
static f39_result_t query_unsigned(f39_reply_t *reply, const char *name,
                                   unsigned long value)
{
    reply_clear(reply);
    return reply_result(reply, name, reply_append(reply, "%s,%lu=Success!\r\n", name, value));
}

static f39_result_t query_text(f39_reply_t *reply, const char *name,
                               const char *value, int capacity)
{
    reply_clear(reply);
    return reply_result(reply, name, reply_append(reply, "%s,%.*s=Success!\r\n", name, capacity, value));
}

void f39_apply_effects(uint32_t effects, f39_platform_t *p)
{
    if ((effects & F39_EFFECT_TIMER_REFRESH) != 0U && F39_READY(p, timer_refresh)) {
        F39_INVOKE(p, timer_refresh, p->context);
    }
    if ((effects & (F39_EFFECT_MAIN_AUTH_RESET |
                    F39_EFFECT_BACKUP_AUTH_RESET)) != 0U &&
        F39_READY(p, jt808_auth_reset)) {
        uint8_t channel_mask = 0U;
        if ((effects & F39_EFFECT_MAIN_AUTH_RESET) != 0U)
            channel_mask |= F39_AUTH_CHANNEL_MAIN;
        if ((effects & F39_EFFECT_BACKUP_AUTH_RESET) != 0U)
            channel_mask |= F39_AUTH_CHANNEL_BACKUP;
        F39_INVOKE(p, jt808_auth_reset, channel_mask, p->context);
    }
    if ((effects & F39_EFFECT_NETWORK_RECONNECT) != 0U && F39_READY(p, network_reconnect)) {
        F39_INVOKE(p, network_reconnect, p->context);
    }
    if ((effects & F39_EFFECT_MODEM_PDP_RESTART) != 0U &&
        F39_READY(p, modem_pdp_restart)) {
        F39_INVOKE(p, modem_pdp_restart, p->context);
    }
    if ((effects & F39_EFFECT_GNSS_REFRESH) != 0U && F39_READY(p, gnss_set_mode) &&
        p->config != NULL) {
        F39_INVOKE(p, gnss_set_mode, p->config->gnss_type, p->config->gpsbds_mode, p->context);
    }
    if ((effects & F39_EFFECT_JT808_REREGISTER) != 0U && F39_READY(p, jt808_reregister)) {
        F39_INVOKE(p, jt808_reregister, p->context);
    }
    if ((effects & F39_EFFECT_REMAINING_REFRESH) != 0U && F39_READY(p, remaining_refresh)) {
        F39_INVOKE(p, remaining_refresh, p->context);
    }
    if ((effects & F39_EFFECT_FOTA_RECHECK) != 0U && F39_READY(p, fota_recheck)) {
        F39_INVOKE(p, fota_recheck, p->context);
    }
}

static bool config_string(const char *s, uint16_t capacity)
{
    uint16_t i;
    if (s == NULL || capacity == 0U) return false;
    for (i = 0U; i < capacity; ++i) if (s[i] == '\0') return true;
    return false;
}

static bool external_text(const char *s, uint16_t length, uint16_t maximum)
{
    return length <= maximum && (length == 0U || s != NULL);
}

static bool valid_config_text(const device_config_t *c)
{
    return config_string(c->terminal_model, CFG_MODEL_LEN) &&
           config_string(c->pid, CFG_PID_LEN) &&
           config_string(c->server_ip, CFG_IP_LEN) &&
           config_string(c->backup_ip, CFG_IP_LEN) &&
           config_string(c->apn, CFG_APN_LEN) &&
           config_string(c->plate_no, CFG_PLATE_LEN) &&
           config_string(c->device_api_key, CFG_DEVICE_API_KEY_LEN);
}

static bool device_id(const device_config_t *c, const f39_platform_t *p,
                      char terminal_id[8])
{
    char imei[F39_IMEI_MAX_LENGTH + 1U];
    if (!external_text(p->imei, p->imei_len, F39_IMEI_MAX_LENGTH)) return false;
    if (p->imei_len > 0U) (void)memcpy(imei, p->imei, p->imei_len);
    imei[p->imei_len] = '\0';
    return terminal_id_derive(c->pid, imei, terminal_id);
}

static bool effects_ready(uint32_t effects, const f39_platform_t *p)
{
    if ((effects & F39_EFFECT_TIMER_REFRESH) != 0U && !F39_READY(p, timer_refresh)) return false;
    if ((effects & F39_EFFECT_NETWORK_RECONNECT) != 0U && !F39_READY(p, network_reconnect)) return false;
    if ((effects & (F39_EFFECT_MAIN_AUTH_RESET |
                    F39_EFFECT_BACKUP_AUTH_RESET)) != 0U &&
        !F39_READY(p, jt808_auth_reset)) return false;
    if ((effects & F39_EFFECT_MODEM_PDP_RESTART) != 0U && !F39_READY(p, modem_pdp_restart)) return false;
    if ((effects & F39_EFFECT_GNSS_REFRESH) != 0U && !F39_READY(p, gnss_set_mode)) return false;
    if ((effects & F39_EFFECT_JT808_REREGISTER) != 0U && !F39_READY(p, jt808_reregister)) return false;
    if ((effects & F39_EFFECT_REMAINING_REFRESH) != 0U && !F39_READY(p, remaining_refresh)) return false;
    if ((effects & F39_EFFECT_FOTA_RECHECK) != 0U && !F39_READY(p, fota_recheck)) return false;
    return true;
}

static f39_result_t query(const f39_request_t *r, f39_platform_t *p,
                          f39_reply_t *out)
{
    const device_config_t *c = p->config;
    const char *name;
    char terminal_id[8];
    if (!f39_operation_name(r->operation, &name) || c == NULL || !valid_config_text(c)) {
        return F39_RESULT_INVALID;
    }
    switch (r->operation) {
    case F39_OPERATION_PARAM:
        reply_clear(out);
        /* Terminal command spec sheet1 row 3: bracketed field format,
         * including the SIM ICCID.  FIP[] stays empty when no backup platform
         * is configured rather than being omitted, so the field set is fixed. */
        if (!external_text(p->version, p->version_len, F39_VERSION_MAX_LENGTH) ||
            !external_text(p->imei, p->imei_len, F39_IMEI_MAX_LENGTH) ||
            !external_text(p->iccid, p->iccid_len, F39_ICCID_MAX_LENGTH) ||
            !device_id(c, p, terminal_id) ||
            !reply_append(out,
                          "PRO[JT808_2013]VER[%.*s]IMEI[%.*s]ICCID[%.*s]"
                          "PID[%.*s]CSQ[%d]GPS[%u]",
                          (int)p->version_len, p->version != NULL ? p->version : "",
                          (int)p->imei_len, p->imei != NULL ? p->imei : "",
                          (int)p->iccid_len, p->iccid != NULL ? p->iccid : "",
                          (int)(CFG_PID_LEN - 1), c->pid,
                          p->csq, (unsigned)p->gps_satellites)) {
            return failure(out, name, "reply-too-long");
        }
        if (c->backup_ip[0] != '\0') {
            if (!reply_append(out, "IP[%.*s:%u]FIP[%.*s:%u]",
                              (int)CFG_IP_LEN, c->server_ip, (unsigned)c->server_port,
                              (int)CFG_IP_LEN, c->backup_ip, (unsigned)c->backup_port)) {
                return failure(out, name, "reply-too-long");
            }
        } else if (!reply_append(out, "IP[%.*s:%u]FIP[]",
                                 (int)CFG_IP_LEN, c->server_ip,
                                 (unsigned)c->server_port)) {
            return failure(out, name, "reply-too-long");
        }
        /* The APN user and password fields are deliberately left empty, as in
         * the spec's own APN[CMIOT,,] example: this reply goes out over SMS in
         * cleartext, and echoing stored credentials there would leak them. */
        if (!reply_append(out, "FORCE[%u:%u]ACC[%u]APN[%.*s,,]\r\n",
                          (unsigned)c->report_moving_s,
                          (unsigned)c->report_stopped_s,
                          p->acc_on ? 1U : 0U,
                          (int)CFG_APN_LEN, c->apn)) {
            return failure(out, name, "reply-too-long");
        }
        return F39_RESULT_OK;
    case F39_OPERATION_PID:
        reply_clear(out);
        {
            /* Terminal command spec sheet1: PID# echoes the full 11-digit
             * device ID, not the 7-byte JT808 terminal id derived from it. */
            const char *pid_text = c->pid;
            if (!device_id(c, p, terminal_id)) return failure(out,name,"identity");
            if (c->pid[0] == '\0') {
                if (p->imei_len != 15U) return failure(out,name,"identity");
                pid_text = p->imei + 4U;
            }
            return reply_result(out, name, reply_append(out, "PID,%.*s=Success!\r\n", (int)(CFG_PID_LEN - 1U), pid_text));
        }
    case F39_OPERATION_IP:
    case F39_OPERATION_FIP: {
        bool backup = r->operation == F39_OPERATION_FIP;
        reply_clear(out);
        if (backup && c->backup_ip[0] == '\0') {
            return reply_result(out, name, reply_append(out, "FIP,0=Success!\r\n"));
        }
        return reply_result(out, name, reply_append(out, "%s,%.*s,%u=Success!\r\n", name, (int)CFG_IP_LEN,
                            backup ? c->backup_ip : c->server_ip,
                            (unsigned)(backup ? c->backup_port : c->server_port)));
    }
    case F39_OPERATION_FREQ:
        reply_clear(out);
        return reply_result(out, name, reply_append(out, "FREQ,%u,%u=Success!\r\n", (unsigned)c->report_moving_s,
                            (unsigned)c->report_stopped_s));
    case F39_OPERATION_HBT:
        return query_unsigned(out, name, c->heartbeat_s);
    case F39_OPERATION_FKEY:
        reply_clear(out);
        return reply_result(out, name, reply_append(out, "FKEY,CONFIGURED=%u\r\n",
                            c->device_api_key[0] == '\0' ? 0U : 1U));
    case F39_OPERATION_FOTA:
        reply_clear(out); return reply_result(out, name, reply_append(out, "FOTA,STATUS=%u\r\n", (unsigned)fota_get_state()));
    case F39_OPERATION_LOG:
        reply_clear(out); return reply_result(out, name, reply_append(out, "LOG,SEND_RESULT=%d\r\n", log_platform_send_result()));
    case F39_OPERATION_MODEL:
        return query_text(out, name, c->terminal_model, CFG_MODEL_LEN);
    case F39_OPERATION_SPEED:
        return query_unsigned(out, name, c->speed_limit_kmh);
    case F39_OPERATION_APN:
        return query_text(out, name, c->autoapn_en ? "AUTO" : c->apn, CFG_APN_LEN);
    case F39_OPERATION_GPSDUP:
        return query_unsigned(out, name, c->sleep_report_mode ? 0UL : 1UL);
    case F39_OPERATION_MLG:
        return query_unsigned(out, name, c->mileage_m / 100U);
    case F39_OPERATION_CAR: {
        uint8_t plate[CFG_PLATE_LEN + 1U];
        uint8_t n = plate_encode_gbk(c->plate_no, plate, CFG_PLATE_LEN);
        plate[n] = '\0';
        return query_text(out, name, (const char *)plate, sizeof plate);
    }
    case F39_OPERATION_GPSBDS:
        return query_unsigned(out, name, c->gpsbds_mode);
    case F39_OPERATION_GMTSET:
        reply_clear(out); return reply_result(out, name, reply_append(out,"GMTSET,%c%02u%02u=Success!\r\n",c->gmt_sign<0?'W':'E',(unsigned)c->gmt_hour,(unsigned)c->gmt_min));
    case F39_OPERATION_VIBSENS:
        return query_unsigned(out, name, c->vib_sens);
    default: return F39_RESULT_INVALID;
    }
}

/* Return the failure reason so reply formatting runs after tx leaves the stack. */
static const char *execute_config(const f39_request_t *request,
                                  f39_platform_t *platform, uint32_t *effects)
    __attribute__((noinline));
static const char *execute_config(const f39_request_t *request,
                                  f39_platform_t *platform, uint32_t *effects)
{
    f39_transaction_t tx;
    if (platform->config == NULL || !F39_READY(platform, persist)) return "invalid";
    f39_transaction_init(&tx, platform->config, platform->persist, platform->context);
    if (!f39_prepare_config(request, platform->config, &tx)) {
        return "config";
    }
    if (!effects_ready(tx.effects, platform) ||
        ((tx.effects & F39_EFFECT_GNSS_REFRESH) != 0U &&
        (!F39_READY(platform, gnss_set_mode) ||
         (tx.candidate.gnss_type != GNSS_TYPE_TAU804M)))) {
        return "unsupported-receiver";
    }
    if (f39_commit_config(&tx) != F39_RESULT_OK) {
        return "config";
    }
    *effects = tx.effects;
    return NULL;
}

f39_result_t f39_execute_deferred(const f39_request_t *request,
                         f39_platform_t *platform,
                         f39_reply_t *reply, uint32_t *effects)
{
    const char *name;
    const char *reason;
    char value[32];
    if (effects == NULL) return F39_RESULT_INVALID;
    *effects = F39_EFFECT_NONE;
    if (reply == NULL) return F39_RESULT_INVALID;
    reply_clear(reply);
    if (request == NULL || platform == NULL || !f39_operation_name(request->operation, &name)) {
        return failure(reply, "F39", "invalid");
    }
    if (request->operation == F39_OPERATION_PARAM ||
        (request->argc == 0U && request->operation != F39_OPERATION_RESET &&
         request->operation != F39_OPERATION_DUALSET && request->operation != F39_OPERATION_RELAY)) {
        return query(request, platform, reply);
    }
    if (request->operation == F39_OPERATION_RESET) {
        if (request->argc != 0U) return failure(reply,name,"invalid");
        if (success(reply,name) != F39_RESULT_OK) return F39_RESULT_INVALID;
        reply->reset_pending = true;
        reply->reset_delay_ms = F39_RESET_DELAY_MS;
        return F39_RESULT_OK;
    }
    if (request->operation == F39_OPERATION_RELAY) {
        bool cut;
        float current_speed;
        if (request->argc == 0U) {
            bool state = F39_READY(platform, relay_get) &&
                         F39_INVOKE(platform, relay_get, platform->context);
            reply_clear(reply);
            return reply_result(reply, name, reply_append(reply,"RELAY,%u=Success!\r\n",state?1U:0U));
        }
        if (request->argc != 1U ||
            !arg_text(request,0U,value,sizeof(value)) || !F39_READY(platform, relay_set) ||
            (strcmp(value,"0") != 0 && strcmp(value,"1") != 0)) return failure(reply,name,"invalid");
        cut = (value[0] == '1');
        if (cut) {
            if (!F39_READY(platform, gps_valid) ||
                !F39_INVOKE(platform, gps_valid, platform->context) ||
                !F39_READY(platform, gps_speed_kmh)) return failure(reply,name,"unsafe");
            current_speed = F39_INVOKE(platform, gps_speed_kmh, platform->context);
            if (!isfinite(current_speed) || current_speed < 0.0f || current_speed >= 20.0f) {
                return failure(reply,name,"unsafe");
            }
        }
        if (!F39_INVOKE(platform, relay_set, cut, platform->context)) return failure(reply,name,"busy");
        reply_clear(reply);
        return reply_result(reply, name, reply_append(reply,"RELAY,%u=Success!\r\n",cut?1U:0U));
    }
    reason = execute_config(request, platform, effects);
    if (reason != NULL) return failure(reply, name, reason);
    /* Formatting must happen after the configuration transaction frame has
     * returned, especially FKEY's query/stdio path. */
    if (request->operation == F39_OPERATION_FKEY)
        return query(request, platform, reply);
    return success(reply,name);
}

f39_result_t f39_execute(const f39_request_t *request,
                         f39_platform_t *platform, f39_reply_t *reply)
{
    uint32_t effects;
    f39_result_t result = f39_execute_deferred(request, platform, reply, &effects);
    if (effects != F39_EFFECT_NONE) f39_apply_effects(effects, platform);
    return result;
}
