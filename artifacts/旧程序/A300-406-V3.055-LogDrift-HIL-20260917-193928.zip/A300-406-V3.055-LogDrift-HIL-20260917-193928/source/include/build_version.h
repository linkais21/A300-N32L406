/* Auto-generated build version - DO NOT EDIT */
#ifndef BUILD_VERSION_H
#define BUILD_VERSION_H

#define FW_BUILD_NUMBER  "202609171939"
#define FW_BUILD_DATE    "Sep 17 2026 - 19:39:28"
#define FW_FULL_VERSION  "T360-A300_406_20260917193928,V3.055"
#define FW_VERSION_COUNTER  3055UL

#endif /* BUILD_VERSION_H */
