#ifndef A300_BOOTLOADER_BCR_H
#define A300_BOOTLOADER_BCR_H

#include <stdint.h>
#include <stdbool.h>
#include "boot_contract.h"

typedef enum {
    BCR_LOAD_IO_ERROR = -1,
    BCR_LOAD_ABSENT = 0,
    BCR_LOAD_FOUND = 1,
    BCR_LOAD_INVALID = 2
} bcr_load_result_t;

bcr_load_result_t bcr_load(bcr_record_t *out);
bool bcr_commit(const bcr_record_t *record);
bool bcr_valid(const bcr_record_t *record);
bool bcr_note_trial_reset(bool fault_or_watchdog);
bool bcr_mark_trial_healthy(void);
bool boot_bcr_read(uint32_t address, void *data, uint32_t length);
bool boot_bcr_write(uint32_t address, const void *data, uint32_t length);
bool boot_bcr_erase(uint32_t address);
bool boot_bcr_readback(uint32_t address, const void *data, uint32_t length);
/* Bounded spacing between complete slot-pair attempts; never mutates records. */
void boot_bcr_retry_wait(uint32_t attempt, bool io_error);

#endif
