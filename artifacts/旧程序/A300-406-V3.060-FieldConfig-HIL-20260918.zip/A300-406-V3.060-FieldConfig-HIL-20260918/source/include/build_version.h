/* Auto-generated build version - DO NOT EDIT */
#ifndef BUILD_VERSION_H
#define BUILD_VERSION_H

#define FW_BUILD_NUMBER  "202609181746"
#define FW_BUILD_DATE    "Sep 18 2026 - 17:46:45"
#define FW_FULL_VERSION  "T360-A300_406_20260918174645,V3.060"
#define FW_VERSION_COUNTER  3060UL

#endif /* BUILD_VERSION_H */
