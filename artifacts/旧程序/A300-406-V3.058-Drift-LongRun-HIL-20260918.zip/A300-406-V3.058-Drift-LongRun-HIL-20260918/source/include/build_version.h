/* Auto-generated build version - DO NOT EDIT */
#ifndef BUILD_VERSION_H
#define BUILD_VERSION_H

#define FW_BUILD_NUMBER  "202609181037"
#define FW_BUILD_DATE    "Sep 18 2026 - 10:37:29"
#define FW_FULL_VERSION  "T360-A300_406_20260918103729,V3.058"
#define FW_VERSION_COUNTER  3058UL

#endif /* BUILD_VERSION_H */
