/* Auto-generated build version - DO NOT EDIT */
#ifndef BUILD_VERSION_H
#define BUILD_VERSION_H

#define FW_BUILD_NUMBER  "202609181002"
#define FW_BUILD_DATE    "Sep 18 2026 - 10:02:26"
#define FW_FULL_VERSION  "T360-A300_406_20260918100226,V3.057"
#define FW_VERSION_COUNTER  3057UL

#endif /* BUILD_VERSION_H */
